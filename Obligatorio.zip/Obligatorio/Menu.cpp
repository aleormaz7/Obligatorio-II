#include "Menu.h"

void MostrarMenu(int &opcion)
{
    printf("\n\n\t Menu Principal \n");
    printf("1. Agregar un nuevo tramo.\n");
    printf("2. Saber si existe tramo entre dos ciudades.\n");
    printf("3. Ingresar una nueva linea.\n");
    printf("4. Listado de lineas\n");
    printf("5. Agregar una nueva parada a la linea\n");
    printf("6. Listado de paradas del recorrido de una linea(nnmero de parada y nombre de ciudad).\n");
    printf("Opcion: ");
    scanf("%d",&opcion);
}













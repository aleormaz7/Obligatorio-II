#ifndef BOOLEAN_H_INCLUDED
#define BOOLEAN_H_INCLUDED

#include <stdio.h>

typedef enum {FALSE,TRUE} boolean;

#endif // BOOLEAN_H_INCLUDED

#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED

#include <stdio.h>

void MostrarMenu(int &opcion);

#endif // MENU_H_INCLUDED
